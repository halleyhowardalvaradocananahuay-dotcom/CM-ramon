document.addEventListener('DOMContentLoaded', () => {
  const menu = document.querySelector('.menu-btn');
  const nav = document.querySelector('nav');
  if (menu && nav) {
    menu.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      menu.setAttribute('aria-expanded', open);
      menu.textContent = open ? '×' : '☰';
    });
  }
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = Number(el.dataset.count); let start = 0; const duration = 900; const t0 = performance.now();
    const step = t => { const p = Math.min((t-t0)/duration,1); el.textContent = Math.floor((1-Math.pow(1-p,3))*target).toLocaleString('es-PE'); if(p<1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  });
  const search = document.querySelector('#searchService');
  if (search) {
    const cards = [...document.querySelectorAll('.service-card')]; const empty = document.querySelector('#noResults');
    search.addEventListener('input', () => {
      const q = search.value.trim().toLowerCase(); let visible = 0;
      cards.forEach(card => { const ok = card.innerText.toLowerCase().includes(q); card.hidden = !ok; if(ok) visible++; });
      if(empty) empty.hidden = visible !== 0;
    });
  }
  const form = document.querySelector('#contactForm');
  if (form) form.addEventListener('submit', e => { e.preventDefault(); const ok=document.querySelector('#msgOk'); if(ok) ok.style.display='block'; form.reset(); });
});
